# Gmail Relay

একাধিক Gmail account-এ নতুন email এলে সেটা প্রায় সঙ্গে সঙ্গে আপনার Railway server-এর URL-এ POST করে দেয়।

## ১. Gmail প্রস্তুতি (প্রতিটা account-এ)
1. Google Account → Security → **2-Step Verification** চালু করুন।
2. https://myaccount.google.com/apppasswords থেকে একটা **App Password** বানান (16 অক্ষর)।

## ২. Railway-তে deploy
1. এই folder GitHub-এ push করুন → Railway → New Project → Deploy from GitHub।
2. **Volume** যোগ করুন, mount path: `/data` (না দিলে redeploy-এ account মুছে যাবে)।
3. Variables:
   - `WEBHOOK_URL` = আপনার server-এর URL (যেখানে mail যাবে)
   - `WEBHOOK_SECRET` = যেকোনো গোপন লেখা (আপনার server এটা header থেকে যাচাই করবে)
   - `ADMIN_PASSWORD` = dashboard-এর password
   - `ENCRYPTION_KEY` = লম্বা random লেখা
   - `DATA_DIR` = `/data`
   - (ঐচ্ছিক) `INCLUDE_ATTACHMENTS` = `true`
4. Settings → Networking → Generate Domain। সেই link খুলে login করুন (username যা খুশি, password = `ADMIN_PASSWORD`)।
5. Gmail আর App Password দিয়ে account যোগ করুন। **Webhook এ test পাঠান** চেপে দেখে নিন।

## আপনার server যা পাবে
`POST WEBHOOK_URL`, header `X-Webhook-Secret: <আপনার secret>`, body (JSON):
```json
{ "type":"email", "account":"you@gmail.com", "uid":123, "messageId":"...",
  "from":"Name <a@b.com>", "fromAddress":"a@b.com", "to":"...", "subject":"...",
  "date":"2026-10-07T10:00:00.000Z", "text":"...", "html":"...",
  "attachments":[{"filename":"a.pdf","contentType":"application/pdf","size":1234}] }
```
200 ফেরত না দিলে ৪ বার retry হয়; তারপরও ব্যর্থ হলে পরের সংযোগে আবার চেষ্টা করে।

## জেনে রাখুন
- অ্যাপ চালু হওয়ার সময় থেকে আসা নতুন mail-ই forward হয়, পুরনো নয়।
- শুধু INBOX দেখা হয়। Gmail IMAP IDLE ব্যবহার হয়, তাই polling নেই।
- Workspace (company) account-এ admin App Password বন্ধ রাখলে কাজ করবে না।

## ফোনে app হিসেবে install
Dashboard link ফোনের Chrome-এ খুলে ⋮ মেনু → **Install app** (বা Add to Home screen)। iPhone-এ Safari → Share → Add to Home Screen।
